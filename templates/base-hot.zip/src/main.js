window.onload = () => {
  console.log('hello world');
}